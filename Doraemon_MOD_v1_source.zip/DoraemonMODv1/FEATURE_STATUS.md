# FEATURE_STATUS

## APK gốc (aThuan Mod v1.5) – kết quả phân tích
| Mục | Trạng thái | Bằng chứng |
|---|---|---|
| Có màn Main / HomeMenu / Mod / Follow | Đã xác minh | AndroidManifest.xml |
| Dùng Shizuku và quyền bộ nhớ ngoài | Đã xác minh | Manifest: provider Shizuku, MANAGE_EXTERNAL_STORAGE, DUMP |
| Can thiệp dữ liệu/game khác qua Shizuku | Có dấu hiệu, chưa xác minh | Suy ra từ quyền, chưa có bằng chứng về đích cụ thể |
| Logic từng nút "mod" | Không thể khôi phục | classes.dex bị làm rối, có dex2c native, asset mã hóa |

## Doraemon MOD v1
| Tính năng | Trạng thái |
|---|---|
| Kiểm tra Shizuku đã cài, mở Shizuku | Đã triển khai (chưa chạy thử) |
| Giữ màn hình sáng của app | Đã triển khai (chưa chạy thử) |
| Thao tác với ứng dụng đích | Chưa triển khai – cần biết đích và mục tiêu |
| Chức năng mod của APK gốc | Không thể xác minh |
